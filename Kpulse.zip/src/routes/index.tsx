import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import {
  Activity,
  AlertTriangle,
  Bell,
  Box,
  Boxes,
  Check,
  ChevronDown,
  Clock,
  Cpu,
  Database,
  HardDrive,
  Hexagon,
  Lock,
  Mail,
  Rocket,
  ShieldCheck,
  Slack,
  Terminal,
  Webhook,
  XCircle,
  Zap,
} from "lucide-react";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "kpulse — Event-driven Kubernetes monitoring for your first cluster" },
      {
        name: "description",
        content:
          "One Pod, ~64Mi RAM. Slack, email, webhook alerts for the 12 most common Kubernetes failure modes. No Prometheus required.",
      },
      { property: "og:title", content: "kpulse — Kubernetes alerts that just work" },
      {
        property: "og:description",
        content:
          "Day-1 ready cluster monitoring. Install, paste a Slack webhook, get alerts on pod crashes, PVC full, certs expiring, and 9 more.",
      },
      { property: "og:type", content: "website" },
    ],
  }),
  component: Landing,
});

const INSTALL_CMD = "curl -fsSL https://kpulse.io/install.sh | bash";

const monitors = [
  { name: "pod_crashes", desc: "CrashLoopBackOff, OOMKilled, ImagePullBackOff", sev: "critical", icon: XCircle },
  { name: "pod_restarts", desc: "> 5 restarts in 15 min", sev: "warning", icon: Activity },
  { name: "warning_events", desc: "Warning k8s Events, noise filtered", sev: "info", icon: Bell },
  { name: "pvc_usage", desc: "PVC > 80% warn, > 90% crit", sev: "warn/crit", icon: Database },
  { name: "node_conditions", desc: "DiskPressure, MemoryPressure, NotReady", sev: "critical", icon: Cpu },
  { name: "node_disk", desc: "rootfs/imagefs > 85% warn, > 92% crit", sev: "warn/crit", icon: HardDrive },
  { name: "tls_cert_expiry", desc: "TLS Secret < 14d warn, < 3d crit", sev: "warn/crit", icon: Lock },
  { name: "rollout_stuck", desc: "Deployment/StatefulSet rolling > 15 min", sev: "warning", icon: Rocket },
  { name: "job_failed", desc: "Job condition Failed=True", sev: "warning", icon: AlertTriangle },
  { name: "cronjob_missed", desc: "> 2 missed schedules", sev: "warning", icon: Clock },
  { name: "hpa_at_max", desc: "HPA pinned at maxReplicas > 30 min", sev: "warning", icon: Zap },
  { name: "daemonset_unscheduled", desc: "desired != ready > 10 min", sev: "warning", icon: Boxes },
];

const sevColor: Record<string, string> = {
  critical: "text-[color:var(--crit)] bg-[color:var(--crit)]/10 border-[color:var(--crit)]/30",
  warning: "text-[color:var(--warn)] bg-[color:var(--warn)]/10 border-[color:var(--warn)]/30",
  info: "text-accent bg-accent/10 border-accent/30",
  "warn/crit": "text-[color:var(--warn)] bg-[color:var(--warn)]/10 border-[color:var(--warn)]/30",
};

function CopyBlock({ children, label }: { children: string; label?: string }) {
  const [copied, setCopied] = useState(false);
  return (
    <div className="group relative rounded-lg border border-border bg-card/60 backdrop-blur shadow-card overflow-hidden">
      {label && (
        <div className="flex items-center justify-between px-4 py-2 border-b border-border bg-secondary/40">
          <div className="flex items-center gap-2">
            <div className="flex gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-[color:var(--crit)]/60" />
              <span className="w-2.5 h-2.5 rounded-full bg-[color:var(--warn)]/60" />
              <span className="w-2.5 h-2.5 rounded-full bg-[color:var(--ok)]/60" />
            </div>
            <span className="mono text-xs text-muted-foreground">{label}</span>
          </div>
          <button
            onClick={() => {
              navigator.clipboard.writeText(children);
              setCopied(true);
              setTimeout(() => setCopied(false), 1600);
            }}
            className="mono text-xs text-muted-foreground hover:text-accent transition-colors"
          >
            {copied ? "copied" : "copy"}
          </button>
        </div>
      )}
      <pre className="mono text-sm leading-relaxed text-foreground/90 p-4 overflow-x-auto">
        <code>{children}</code>
      </pre>
    </div>
  );
}

function Nav() {
  return (
    <header className="sticky top-0 z-50 border-b border-border/60 bg-background/70 backdrop-blur-xl">
      <div className="max-w-6xl mx-auto px-6 h-16 flex items-center justify-between">
        <a href="#" className="flex items-center gap-2.5">
          <div className="relative">
            <Hexagon className="w-7 h-7 text-primary" strokeWidth={1.5} />
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="w-1.5 h-1.5 rounded-full bg-accent animate-pulse" />
            </div>
          </div>
          <span className="mono font-semibold text-base tracking-tight">kpulse</span>
          <span className="mono text-[10px] px-1.5 py-0.5 rounded border border-border text-muted-foreground">v1</span>
        </a>
        <nav className="hidden md:flex items-center gap-8 text-sm text-muted-foreground">
          <a href="#monitors" className="hover:text-foreground transition-colors">Monitors</a>
          <a href="#install" className="hover:text-foreground transition-colors">Install</a>
          <a href="#channels" className="hover:text-foreground transition-colors">Channels</a>
          <a href="#faq" className="hover:text-foreground transition-colors">FAQ</a>
        </nav>
        <a
          href="https://github.com/dnl555/kpulse"
          className="mono text-xs px-3 py-1.5 rounded-md border border-border hover:border-accent hover:text-accent transition-colors"
        >
          GitHub →
        </a>
      </div>
    </header>
  );
}

function Hero() {
  return (
    <section className="relative overflow-hidden">
      <div className="absolute inset-0 grid-bg" aria-hidden />
      <div className="absolute inset-0 bg-gradient-hero" aria-hidden />

      <div className="relative max-w-6xl mx-auto px-6 pt-24 pb-20 md:pt-32 md:pb-28">
        <div className="flex items-center gap-2 mono text-xs text-accent mb-6">
          <span className="w-1.5 h-1.5 rounded-full bg-accent animate-pulse" />
          <span>v1.0 · MIT · ~1500 LOC Go</span>
        </div>
        <h1 className="text-5xl md:text-7xl font-semibold tracking-tight leading-[1.05] max-w-4xl">
          Kubernetes alerts <br />
          <span className="text-gradient">that just work.</span>
        </h1>
        <p className="mt-6 max-w-2xl text-lg md:text-xl text-muted-foreground leading-relaxed">
          Event-driven monitoring for developers and startups on their first cluster.
          One Pod, one ConfigMap, ~64Mi of memory. Slack, email, and webhooks out of the box.
        </p>

        <div className="mt-10 max-w-2xl">
          <CopyBlock label="~ install kpulse">{INSTALL_CMD}</CopyBlock>
        </div>

        <div className="mt-8 flex flex-wrap items-center gap-4">
          <a
            href="#install"
            className="inline-flex items-center gap-2 px-5 py-3 rounded-md bg-gradient-accent text-primary-foreground font-medium shadow-glow hover:opacity-90 transition-opacity"
          >
            <Terminal className="w-4 h-4" /> Quickstart
          </a>
          <a
            href="#monitors"
            className="inline-flex items-center gap-2 px-5 py-3 rounded-md border border-border hover:border-accent text-foreground transition-colors"
          >
            See what it watches <ChevronDown className="w-4 h-4" />
          </a>
        </div>

        <div className="mt-16 grid grid-cols-2 md:grid-cols-4 gap-6 max-w-3xl">
          {[
            { k: "1", v: "Pod" },
            { k: "~64Mi", v: "Memory" },
            { k: "12", v: "Monitors" },
            { k: "5", v: "Channels" },
          ].map((s) => (
            <div key={s.v} className="border-l-2 border-border pl-4">
              <div className="mono text-2xl md:text-3xl font-semibold text-foreground">{s.k}</div>
              <div className="text-xs uppercase tracking-wider text-muted-foreground mt-1">{s.v}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function Why() {
  const items = [
    {
      icon: Rocket,
      title: "Day-1 ready",
      body: "Install, paste one Slack webhook, you have alerts on the 12 most common failure modes. No tuning weekend required.",
    },
    {
      icon: Box,
      title: "No time-series stack",
      body: "No Prometheus, no Grafana, no Alertmanager, no PVCs. kpulse listens to the Kubernetes API and sends.",
    },
    {
      icon: ShieldCheck,
      title: "Sane defaults",
      body: "All 12 monitors on. Thresholds tuned to be silent on a healthy cluster. Dedupe and digest built-in.",
    },
  ];
  return (
    <section className="relative py-24 border-t border-border">
      <div className="max-w-6xl mx-auto px-6">
        <div className="max-w-2xl">
          <p className="mono text-xs uppercase tracking-widest text-accent mb-3">// why kpulse</p>
          <h2 className="text-3xl md:text-5xl font-semibold tracking-tight">
            The gap before <span className="text-muted-foreground">Prometheus.</span>
          </h2>
        </div>
        <div className="grid md:grid-cols-3 gap-6 mt-14">
          {items.map((i) => (
            <div
              key={i.title}
              className="group relative p-6 rounded-xl border border-border bg-card hover:bg-secondary/30 hover:border-accent/40 transition-all"
            >
              <div className="w-10 h-10 rounded-md bg-primary/15 border border-primary/30 flex items-center justify-center mb-5">
                <i.icon className="w-5 h-5 text-accent" />
              </div>
              <h3 className="text-lg font-semibold mb-2">{i.title}</h3>
              <p className="text-muted-foreground text-sm leading-relaxed">{i.body}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function Monitors() {
  return (
    <section id="monitors" className="relative py-24 border-t border-border">
      <div className="max-w-6xl mx-auto px-6">
        <div className="flex items-end justify-between flex-wrap gap-6 mb-12">
          <div className="max-w-2xl">
            <p className="mono text-xs uppercase tracking-widest text-accent mb-3">// 12 monitors out of the box</p>
            <h2 className="text-3xl md:text-5xl font-semibold tracking-tight">
              The failures that wake teams up.
            </h2>
            <p className="mt-4 text-muted-foreground">
              Each fires on a tuned threshold. Each can be silenced or rerouted via ConfigMap.
            </p>
          </div>
          <a href="#" className="mono text-xs text-accent hover:underline">docs/monitors.md →</a>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {monitors.map((m) => (
            <div
              key={m.name}
              className="group p-4 rounded-lg border border-border bg-card hover:bg-secondary/30 hover:border-accent/40 transition-all"
            >
              <div className="flex items-start justify-between gap-3">
                <div className="flex items-center gap-2.5 min-w-0">
                  <div className="w-8 h-8 rounded-md bg-secondary border border-border flex items-center justify-center shrink-0">
                    <m.icon className="w-4 h-4 text-accent" />
                  </div>
                  <span className="mono text-sm font-medium truncate">{m.name}</span>
                </div>
                <span className={`mono text-[10px] uppercase px-1.5 py-0.5 rounded border ${sevColor[m.sev]}`}>
                  {m.sev}
                </span>
              </div>
              <p className="text-xs text-muted-foreground mt-3 leading-relaxed">{m.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function Install() {
  const configCmds = `kubectl -n kpulse edit configmap kpulse-config   # set cluster.name, enable a channel
kubectl -n kpulse edit secret kpulse-secrets     # add e.g. SLACK_WEBHOOK_URL
kubectl -n kpulse rollout restart deploy/kpulse`;

  const testCmd = `kubectl -n kpulse port-forward svc/kpulse 8080:8080 &
curl 'http://localhost:8080/test-channel?name=slack'`;

  return (
    <section id="install" className="relative py-24 border-t border-border">
      <div className="max-w-6xl mx-auto px-6">
        <div className="max-w-2xl mb-12">
          <p className="mono text-xs uppercase tracking-widest text-accent mb-3">// install</p>
          <h2 className="text-3xl md:text-5xl font-semibold tracking-tight">
            Three commands. One alert pipeline.
          </h2>
        </div>

        <ol className="space-y-6 max-w-3xl">
          <Step n="1" title="Install">
            <CopyBlock label="$ install">{INSTALL_CMD}</CopyBlock>
          </Step>
          <Step n="2" title="Configure a channel">
            <CopyBlock label="$ configure">{configCmds}</CopyBlock>
          </Step>
          <Step n="3" title="Test it">
            <CopyBlock label="$ test">{testCmd}</CopyBlock>
          </Step>
        </ol>

        <div className="mt-12 grid md:grid-cols-3 gap-4 max-w-3xl">
          <InstallMethod title="Raw manifest" cmd="kubectl apply -f https://github.com/dnl555/kpulse/releases/latest/download/kpulse.yaml" />
          <InstallMethod
            title="Helm"
            cmd="helm install kpulse ./charts/kpulse"
            href="https://github.com/dnl555/kpulse/tree/main/charts/kpulse"
          />
          <InstallMethod title="Local build" cmd="git clone … && make build image" />
        </div>
      </div>
    </section>
  );
}

function Step({ n, title, children }: { n: string; title: string; children: React.ReactNode }) {
  return (
    <li className="flex gap-5">
      <div className="shrink-0 w-9 h-9 rounded-full border border-accent/40 bg-accent/10 flex items-center justify-center mono text-sm text-accent font-semibold">
        {n}
      </div>
      <div className="flex-1 min-w-0">
        <h3 className="text-base font-semibold mb-3">{title}</h3>
        {children}
      </div>
    </li>
  );
}

function InstallMethod({ title, cmd, href }: { title: string; cmd: string; href?: string }) {
  const Card = (
    <div className="p-4 rounded-lg border border-border bg-card hover:border-accent/40 transition-colors">
      <div className="text-xs uppercase tracking-wider text-muted-foreground mb-2">{title}</div>
      <code className="mono text-xs text-foreground/80 break-all">{cmd}</code>
    </div>
  );
  if (href) {
    return (
      <a href={href} target="_blank" rel="noopener noreferrer" className="block">
        {Card}
      </a>
    );
  }
  return Card;
}

function Channels() {
  const items = [
    { icon: Slack, name: "Slack", desc: "Webhook URL, threaded digests." },
    { icon: Mail, name: "SMTP Email", desc: "Plain SMTP, no provider lock-in." },
    { icon: Webhook, name: "Webhook", desc: "JSON POST to any URL." },
    { icon: Bell, name: "Discord", desc: "Native embed format." },
    { icon: Hexagon, name: "MS Teams", desc: "Adaptive card payloads." },
  ];
  return (
    <section id="channels" className="relative py-24 border-t border-border">
      <div className="max-w-6xl mx-auto px-6">
        <div className="grid md:grid-cols-5 gap-12 items-start">
          <div className="md:col-span-2">
            <p className="mono text-xs uppercase tracking-widest text-accent mb-3">// channels</p>
            <h2 className="text-3xl md:text-5xl font-semibold tracking-tight">
              Ping the channel <br /> of your choice.
            </h2>
            <p className="mt-4 text-muted-foreground">
              Pick any subset. Every alert goes through the same dedupe and digest engine before it leaves the cluster.
            </p>
          </div>
          <div className="md:col-span-3 grid sm:grid-cols-2 gap-3">
            {items.map((c) => (
              <div
                key={c.name}
                className="flex items-start gap-4 p-4 rounded-lg border border-border bg-card hover:border-accent/40 transition-colors"
              >
                <div className="w-10 h-10 rounded-md bg-primary/15 border border-primary/30 flex items-center justify-center shrink-0">
                  <c.icon className="w-5 h-5 text-accent" />
                </div>
                <div>
                  <div className="font-medium text-sm">{c.name}</div>
                  <div className="text-xs text-muted-foreground mt-1">{c.desc}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

function NotSection() {
  const yes = [
    "Day-1 alerts on common failures",
    "Lightweight: 1 Pod, ~64Mi RAM",
    "Slack / SMTP / Webhook / Discord / Teams",
    "Sensible thresholds out of the box",
    "Dedupe + digest engine",
  ];
  const no = [
    "Not a metrics store",
    "No PromQL or time-series",
    "No dashboard or UI in v1",
    "No silencing schedules / on-call",
    "Not a Prometheus replacement",
  ];
  return (
    <section className="relative py-24 border-t border-border">
      <div className="max-w-6xl mx-auto px-6">
        <div className="grid md:grid-cols-2 gap-6">
          <div className="p-8 rounded-xl border border-[color:var(--ok)]/30 bg-[color:var(--ok)]/5">
            <div className="flex items-center gap-2 mb-5">
              <Check className="w-5 h-5 text-[color:var(--ok)]" />
              <h3 className="font-semibold">kpulse IS</h3>
            </div>
            <ul className="space-y-3">
              {yes.map((t) => (
                <li key={t} className="flex items-start gap-2.5 text-sm text-foreground/90">
                  <Check className="w-4 h-4 text-[color:var(--ok)] mt-0.5 shrink-0" /> {t}
                </li>
              ))}
            </ul>
          </div>
          <div className="p-8 rounded-xl border border-border bg-card">
            <div className="flex items-center gap-2 mb-5">
              <XCircle className="w-5 h-5 text-muted-foreground" />
              <h3 className="font-semibold">kpulse is NOT</h3>
            </div>
            <ul className="space-y-3">
              {no.map((t) => (
                <li key={t} className="flex items-start gap-2.5 text-sm text-muted-foreground">
                  <XCircle className="w-4 h-4 mt-0.5 shrink-0" /> {t}
                </li>
              ))}
            </ul>
            <p className="mt-6 text-xs text-muted-foreground leading-relaxed border-t border-border pt-4">
              Need those? Run Prometheus + Grafana + Alertmanager. kpulse covers the gap before
              you're ready for that stack — and keeps doing the noisy "did Kubernetes break again" work after.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}

function FAQ() {
  const qs = [
    {
      q: "Does kpulse replace Prometheus?",
      a: "No. It covers the alerting gap before you've set up Prometheus, and continues handling the noisy 'did Kubernetes break?' alerts alongside it.",
    },
    {
      q: "How much does it cost to run?",
      a: "One Pod, ~64Mi memory, ~10m CPU. On most clusters, the overhead is invisible.",
    },
    {
      q: "What permissions does it need?",
      a: "Read access to Pods, Events, PVCs, Nodes, Deployments, StatefulSets, Jobs, CronJobs, HPAs, DaemonSets, and Secrets (for TLS expiry checks).",
    },
    {
      q: "Can I silence specific alerts?",
      a: "Not via silencing rules. You can disable monitors entirely or tune thresholds in the ConfigMap. For full silencing, route to Alertmanager.",
    },
    {
      q: "Is it open source?",
      a: "Yes. MIT licensed. ~1500 LOC of Go in 7 packages. Issues and PRs welcome.",
    },
  ];
  return (
    <section id="faq" className="relative py-24 border-t border-border">
      <div className="max-w-3xl mx-auto px-6">
        <p className="mono text-xs uppercase tracking-widest text-accent mb-3">// faq</p>
        <h2 className="text-3xl md:text-5xl font-semibold tracking-tight mb-12">Questions.</h2>
        <div className="divide-y divide-border border-y border-border">
          {qs.map((item, idx) => (
            <details key={idx} className="group py-5">
              <summary className="flex items-center justify-between cursor-pointer list-none">
                <span className="font-medium text-foreground pr-4">{item.q}</span>
                <ChevronDown className="w-4 h-4 text-muted-foreground shrink-0 transition-transform group-open:rotate-180" />
              </summary>
              <p className="mt-3 text-sm text-muted-foreground leading-relaxed">{item.a}</p>
            </details>
          ))}
        </div>
      </div>
    </section>
  );
}

function CTA() {
  return (
    <section className="relative py-24 border-t border-border overflow-hidden">
      <div className="absolute inset-0 grid-bg opacity-50" aria-hidden />
      <div className="relative max-w-4xl mx-auto px-6 text-center">
        <h2 className="text-3xl md:text-5xl font-semibold tracking-tight">
          Stop discovering crashes <br />
          <span className="text-gradient">from your users.</span>
        </h2>
        <p className="mt-5 text-muted-foreground max-w-xl mx-auto">
          One command. One Slack webhook. Twelve fewer pages at 3am.
        </p>
        <div className="mt-10 max-w-xl mx-auto">
          <CopyBlock label="~ get started">{INSTALL_CMD}</CopyBlock>
        </div>
      </div>
    </section>
  );
}

function Footer() {
  return (
    <footer className="border-t border-border py-12">
      <div className="max-w-6xl mx-auto px-6 flex flex-wrap items-center justify-between gap-6">
        <div className="flex items-center gap-2.5">
          <Hexagon className="w-5 h-5 text-primary" strokeWidth={1.5} />
          <span className="mono text-sm">kpulse</span>
          <span className="text-xs text-muted-foreground">· MIT · kpulse.io</span>
        </div>
        <div className="flex gap-6 text-xs text-muted-foreground mono">
          <a href="#" className="hover:text-accent transition-colors">docs</a>
          <a href="https://github.com/dnl555/kpulse" className="hover:text-accent transition-colors">github</a>
          <a href="#" className="hover:text-accent transition-colors">changelog</a>
          <a href="#" className="hover:text-accent transition-colors">license</a>
        </div>
      </div>
    </footer>
  );
}

function Landing() {
  return (
    <div className="min-h-screen bg-background text-foreground">
      <Nav />
      <main>
        <Hero />
        <Why />
        <Monitors />
        <Install />
        <Channels />
        <NotSection />
        <FAQ />
        <CTA />
      </main>
      <Footer />
    </div>
  );
}
